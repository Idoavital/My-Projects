
#define FULL_H

#include "singleTon.h"
#include "test.h"

using namespace ilrd;
void GetInstance()
{
   singleTon<test> s;
  
}
