#include <iostream>
void foo() {}
void foo(int i){}
void foo(char x){}



static inline void foo1()
{
std::cout<<"dgfggt"<<std::endl;
}

int main()
{
#if 0 - A


    int i;
    float* f= &i;
    const int* icp =&i;
    int* ip = icp;
#endif

#if 0 - B

    int y (3);
    int x =6;
    std::cerr<<"dsaddasd x ="<<x<< " y = "<< y <<std::endl;

#endif  //0
foo1();
return 0;
}


